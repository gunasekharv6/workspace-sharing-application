import React, { Component } from 'react';
import front4 from '../../img/front4.jpg';
import front5 from '../../img/front5.jpg';
import front6 from '../../img/front6.jpg';

class Background extends Component {
    render() {
        return (

            <div id="carouselExampleCaptions" className="carousel slide1" data-bs-ride="carousel">
                <div className="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src={front4} className=" w-100" alt="..." />
                        <div class="carousel-caption d-none d-md-block">
                            <h1 style={{ color: 'white' }}>Find Your Space</h1>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src={front5} className=" w-100" style={{ height: '800px' }} alt="..." />
                        <div class="carousel-caption d-none d-md-block">
                            <h1>Collaborate and Succeed!</h1>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src={front6} className=" w-100" style={{ height: '800px' }} alt="..." />
                        <div class="carousel-caption d-none d-md-block">
                            <h1>Be the Difference!</h1>
                        </div>
                    </div>
                </div>
            </div >
        );
    }
}

export default Background;